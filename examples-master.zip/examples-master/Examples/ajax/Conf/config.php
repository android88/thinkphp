<?php
return array(
    'URL_MODEL'		=>	2, // 如果你的环境不支持PATHINFO 请设置为3
    'DB_TYPE'		=>	'mysql',
    'DB_HOST'		=>	'localhost',
    'DB_NAME'		=>	'examples',
    'DB_USER'		=>	'root',
    'DB_PWD'		=>	'',
    'DB_PORT'		=>	'3306',
    'DB_PREFIX'		=>	'think_',
);