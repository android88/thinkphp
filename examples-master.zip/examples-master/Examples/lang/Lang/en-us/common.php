<?php
return array(
	'welcome'=>'Welcome to ThinkPHP!',
	'remark'=>'now is english language!',
);
?>