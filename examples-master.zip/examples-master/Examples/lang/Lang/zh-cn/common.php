<?php
return array(
	'welcome'=>'欢迎使用ThinkPHP',
	'remark'=>'您看到的是简体中文',
);
?>