<?php
return array(
    'URL_MODEL'         =>  1,
    'URL_PATHINFO_DEPR' =>  '/',
    'DB_TYPE'           =>  'mysql',
    'DB_HOST'           =>  'localhost',
    'DB_NAME'           =>  'examples',
    'DB_USER'           =>  'root',
    'DB_PWD'            =>  '',
    'DB_PORT'           =>  '3306',
    'DB_PREFIX'         =>  'think_',
    'VAR_PAGE'          =>  'p',
);