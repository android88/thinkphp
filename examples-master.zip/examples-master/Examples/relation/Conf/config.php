<?php
return array(
    'URL_MODEL'     =>  1,
    'DB_TYPE'       =>  'mysql',
    'DB_HOST'       =>  'localhost',
    'DB_NAME'       =>  'examples',
    'DB_USER'       =>  'root',
    'DB_PWD'        =>  '',
    'DB_PORT'       =>  '3306',
    'DB_PREFIX'     =>  'think_',
);