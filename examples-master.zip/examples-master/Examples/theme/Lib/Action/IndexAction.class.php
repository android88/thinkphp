<?php
class IndexAction extends Action {
}