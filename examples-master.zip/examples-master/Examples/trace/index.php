<?php
define('APP_NAME', 'trace');
define('APP_PATH', './');
// 加载框架入口文件
define('APP_DEBUG', true);
require( "../ThinkPHP/ThinkPHP.php");